package GeneticAlgorithm;

public enum Mode {
	TwoPoint, OnePoint, Tournament, Roulette
}
